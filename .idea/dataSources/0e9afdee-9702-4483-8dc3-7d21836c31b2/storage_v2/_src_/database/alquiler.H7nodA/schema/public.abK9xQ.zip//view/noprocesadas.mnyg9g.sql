create view noprocesadas as
  SELECT reservasall.id,
    reservasall.usuario,
    reservasall.equipo,
    reservasall.horario,
    reservasall.estado,
    reservasall.fecha,
    reservasall.fecha_reserva
   FROM reservasall
  WHERE ((reservasall.fecha_reserva < ('now'::text)::date) AND ((reservasall.estado)::text = 'Reservado'::text));

