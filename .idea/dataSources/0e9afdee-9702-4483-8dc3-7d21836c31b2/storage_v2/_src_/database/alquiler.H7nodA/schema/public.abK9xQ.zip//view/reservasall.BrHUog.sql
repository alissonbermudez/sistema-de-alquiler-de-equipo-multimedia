create view reservasall as
  SELECT a.id,
    a.usuario,
    a.equipo,
    b.horario,
    c.estado,
    a.fecha,
    a.fecha_reserva
   FROM ((reservas a
     JOIN horarios b ON ((a.horario = b.id)))
     JOIN estado_reserva c ON ((a.estado = c.id)));

