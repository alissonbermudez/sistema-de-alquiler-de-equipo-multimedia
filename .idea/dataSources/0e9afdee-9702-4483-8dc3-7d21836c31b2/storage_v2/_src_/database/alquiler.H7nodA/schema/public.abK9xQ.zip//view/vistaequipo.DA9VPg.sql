create view vistaequipo as
  SELECT equipo.idequipo,
    equipo.marca,
    equipo.modelo,
    equipo.serie,
    equipo.tipo,
    equipo.descripcion,
    equipo.fechaadq,
    equipo.estado
   FROM equipo;

