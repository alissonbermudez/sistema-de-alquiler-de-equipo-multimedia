create function limpiar()
  returns boolean
security definer
language plpgsql
as $$
BEGIN

  UPDATE reservas SET estado=4 WHERE fecha_reserva<current_date AND estado=1;

  RETURN FOUND;

END;

$$;

