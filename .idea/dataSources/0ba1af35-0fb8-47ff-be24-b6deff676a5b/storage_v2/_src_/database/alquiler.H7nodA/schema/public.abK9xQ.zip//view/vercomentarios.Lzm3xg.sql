create view vercomentarios as
  SELECT a.idcoment,
    a.fecha,
    a.titulo,
    a.comentar,
    b.equipo,
    b.comentario
   FROM (comentarios a
     FULL JOIN equipo_comentario b ON ((b.comentario = a.idcoment)));

