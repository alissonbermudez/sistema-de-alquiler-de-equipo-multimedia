create view ncancel as
  SELECT count(*) AS num
   FROM reservasall
  WHERE ((reservasall.fecha_reserva < ('now'::text)::date) AND ((reservasall.estado)::text = 'Reservado'::text));

